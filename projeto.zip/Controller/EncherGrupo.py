from PyQt5.QtWidgets import QDialog, QListWidgetItem,QTableWidgetItem,QPushButton
from PyQt5 import QtCore
from PyQt5.QtGui import QIcon
from Enums.TipoConta import TipoConta
from Views.EncherGrupoView import Ui_Dialog as Ui_EncherGrupoDialog
from Database.Database import Database
from Threads.ThreadEncherGrupo import ThreadEncherGrupo
from Enums.StatusTarefa import StatusTarefa

class EncherGrupoController():
    def __init__(self, main_window):
        self.main_window = main_window
        self.main_window.btnAddTarefaGrupo.clicked.connect(self.open_encher_grupo_dialog)
        self.main_window.btnRemoveTarefaGrupo.setEnabled(True)
        self.main_window.btnRemoveTarefaGrupo.clicked.connect(self.remove_selected_row)
        self.database = Database()
        self.threads = []
        self.load_tarefas()

    def open_encher_grupo_dialog(self):
        self.dialog = QDialog()
        self.ui = Ui_EncherGrupoDialog()
        self.ui.setupUi(self.dialog)
        self.load_data()
        self.ui.btnSalvar.clicked.connect(self.start_encher_grupo_thread)
        self.dialog.exec_()

    def load_tarefas(self):
        tarefas = self.database.get_all_tarefas()
        for tarefa in tarefas:
            members = self.database.get_membros_by_tarefa(tarefa['id'])
            count = len(set([member['conta'] for member in members]))
            adicionados = sum([1 for member in members if member['status'] == '0'])

            self.insert_table_tarefa(tarefa['id'], tarefa['grupo_origem'], tarefa['grupo_destino'], 0, adicionados if adicionados else 0, count if count else 0,StatusTarefa(tarefa['status']).name)

    def remove_selected_row(self):
        row = self.main_window.tableTarefasGrupo.currentRow()
        id_tarefa = self.main_window.tableTarefasGrupo.item(row, 1).text()
        self.database.delete_tarefa(id_tarefa)
        self.database.delete_membros_by_tarefa(id_tarefa)
        self.main_window.tableTarefasGrupo.removeRow(row)


    def load_data(self):
        groups = self.database.get_all_groups()
        self.ui.comboExtrair.clear()
        self.ui.comboAdicionar.clear()
        for group in groups:
            self.ui.comboExtrair.addItem(f"{group['desc']}", group)
            self.ui.comboAdicionar.addItem(f"{group['desc']}", group)

        accounts = self.database.get_accounts_by_status(0)
        self.ui.listContasWidget.clear()
        for account in accounts:
            item = QListWidgetItem(f"{account['file_session']} | {account['apelido']}")
            item.setData(QtCore.Qt.UserRole, account)
            self.ui.listContasWidget.addItem(item)

    def start_encher_grupo_thread(self):
        origin_group = self.ui.comboExtrair.currentData()
        target_group = self.ui.comboAdicionar.currentData()

        selected_items = self.ui.listContasWidget.selectedItems()
        accounts = [item.data(QtCore.Qt.UserRole) for item in selected_items]

        options = {
            'limite_dia': self.ui.spinLimiteDia.value(),
            'intervalo_dia': self.ui.spinDias.value(),
            'intervalo': self.ui.spinIntevalo.value(),
            "ativos": self.ui.checkAtivos.isChecked(),
            "remover_administradores": self.ui.checkAdministrador.isChecked(),
            "telefone": self.ui.checkTelefone.isChecked(),
            "foto": self.ui.checkFoto.isChecked()
        }

        options_db = {
            'limite_diario': self.ui.spinLimiteDia.value(),
            'intervalo_dia': self.ui.spinDias.value(),
            'intervalo': self.ui.spinIntevalo.value(),
            "ativos": 'Sim' if self.ui.checkAtivos.isChecked() else 'Não',
            "remover_administradores": 'Sim' if self.ui.checkAdministrador.isChecked() else 'Não',
            "telefone": 'Sim' if self.ui.checkTelefone.isChecked() else 'Não',
            "foto": 'Sim' if self.ui.checkFoto.isChecked() else 'Não'
        }

        if origin_group.get("link") == target_group.get("link"):
            self.ui.labelStatus.setText("<font color='red'>Os grupos de origem e destino não podem ser iguais.</font>")
            return
        if len(accounts) == 0:
            self.ui.labelStatus.setText("<font color='red'>Selecione ao menos uma conta.</font>")
            return
        
        id_tarefa = self.database.insert_tarefa(origin_group.get('desc'),target_group.get('desc'), StatusTarefa.PAUSADO_EXTRAINDO.value,options_db.get('intervalo'),options_db.get('ativos'),options_db.get('foto'),options_db.get('intervalo_dia'),options_db.get('limite_diario'),options_db.get('remover_administradores'),options_db.get('telefone'))
        #self.insert_table_tarefa(id_tarefa, origin_group.get('desc'), target_group.get('desc'), 0, 0, len(accounts), 'Pausado')
        

        print(origin_group, target_group, accounts, options)
        
        self.thread = ThreadEncherGrupo(id_tarefa,accounts, origin_group.get('link'), target_group.get('link'), options)
        self.thread.sinalMsg.connect(self.update_status)
        self.thread.sinalAdicionados.connect(self.update_adicionados)
        self.thread.sinalStatus.connect(self.update_status)
        self.thread.sinalAnalisados.connect(self.update_analisados)
        self.thread.sinalContaStatus.connect(self.change_status)
        self.thread.sinalQuit.connect(self.quit_thread)
        self.thread.sinalInsertTable.connect(lambda: self.insert_table_tarefa(id_tarefa, origin_group.get('desc'), target_group.get('desc'), 0, 0, len(accounts), 'Pausado'))
        self.thread.sinalDeleteTable.connect(lambda: self.database.delete_tarefa(id_tarefa))
        #self.threads.append(thread)
        self.thread.start()

        #self.dialog.close()

    def insert_table_tarefa(self, id_tarefa, origin_group, target_group, analisados, adicionados,num_contas,status):
        print('inserindo')
        self.main_window.tableTarefasGrupo.insertRow(0)

        items = [
            QTableWidgetItem(str(id_tarefa)),
            QTableWidgetItem(str(origin_group)),
            QTableWidgetItem(str(target_group)),
            QTableWidgetItem(str(f'{analisados}%')),
            QTableWidgetItem(str(adicionados)),
            QTableWidgetItem(str(num_contas)),
            QTableWidgetItem(str(status.split('_')[0])) if '_' in status else QTableWidgetItem(str(status))
        ]
        
        
        
        self.button = QPushButton("Iniciar")
        self.button.setIcon(QIcon("D:/Robô Telegram Pro/Views/UI\\../Icons/start.png"))

        self.main_window.tableTarefasGrupo.setCellWidget(0, 0, self.button)

        for column, item in enumerate(items, start=1):  
            item.setTextAlignment(QtCore.Qt.AlignCenter)
            self.main_window.tableTarefasGrupo.setItem(0, column, item)


    def start_pause_thread(self):
        if self.button.text() == "Pausar":
            self.button.setText("Iniciar")
            self.button.setIcon(QIcon("D:/Robô Telegram Pro/Views/UI\\../Icons/start.png"))
        else:
            self.button.setText("Pausar")
            self.button.setIcon(QIcon("D:/Robô Telegram Pro/Views/UI\\../Icons/stop.png"))
            

    def update_adicionados(self, adicionados):
        self.main_window.tableTarefasGrupo.item(0, 5).setText(str(adicionados))

    def update_status(self, status):
        #self.main_window.tableTarefasGrupo.item(0, 7).setText(status)
        self.ui.labelStatus.setText(status)
        self.ui.labelStatus.setStyleSheet('color:green')

      
    def quit_thread(self, status):
        print(self.thread.isRunning())
        if not status:
            print('Deu erro')
            self.thread.terminate()
            print('Terminando thread')
            
            self.ui.labelStatus.setStyleSheet('color:red')
            #self.ui.labelStatus.setText(self.ui.labelStatus.text() + f" Fechando em 3 segundos")
            #QtCore.QTimer.singleShot(3000, self.dialog.close)
            
            
            


    def update_analisados(self, value):
        self.main_window.tableTarefasGrupo.item(0, 4).setText(f"{value}%")

    def get_account_info(self, row,status):

        status_conta = self.main_view.tableContas.item(row, 2)
        status_conta.setText(status)

    def change_status(self, phone,status):
        for row in range(self.main_view.tableContas.rowCount()):
            if self.main_view.tableContas.item(row, 1).text() == phone:
                return self.get_account_info(row,status)
        return None

   
