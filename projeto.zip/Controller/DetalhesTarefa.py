from PyQt5.QtWidgets import QDialog, QMessageBox,QTableWidgetItem
from Database.Database import Database
from Views.DetalhesTarefaView import Ui_Dialog
from PyQt5 import QtCore
from Enums.StatusAddMembro import StatusAddMembro
from Enums.StatusConta import StatusConta

class DetalhesTarefaController:
        
        def __init__(self, main_window):
            self.database = Database()
            self.main_window = main_window
            self.main_window.btnDetalhesTarefa.clicked.connect(self.open_add_group_dialog)
            #self.main_window.btnRemoveAquecendo.clicked.connect(self.remove_selected_row)
            #self.main_window.closeEvent = self.handle_close_event
            self.main_window.tableTarefasGrupo.itemClicked.connect(self.enable_detalhes_tarefa_button)
            
        def open_add_group_dialog(self):
            dialog = QDialog()
            self.ui = Ui_Dialog()
            self.ui.setupUi(dialog)
            
            selected_row = self.main_window.tableTarefasGrupo.currentRow()
            if selected_row >= 0:
                selected_item = self.main_window.tableTarefasGrupo.item(selected_row, 1)
                tarefa_id = selected_item.text()
                info_data = self.database.get_tarefa_info(tarefa_id)
                members_data = self.database.get_membros_by_tarefa(tarefa_id)
                self.table_info(info_data)
                self.table_membros(members_data)
                self.table_contas(members_data)
            else:
                QMessageBox.warning(dialog, "Warning", "No row selected.")
            dialog.exec_()

        def enable_detalhes_tarefa_button(self):
            self.main_window.btnDetalhesTarefa.setEnabled(True)
    
        
        def table_info(self,info_data):
            self.ui.labelOrigem.setText(info_data['grupo_origem'])
            self.ui.labelDestino.setText(info_data['grupo_destino'])
            self.ui.labelAtivos.setText(info_data['membros_ativos'])
            self.ui.labelLimiteDiario.setText(info_data['limite_diario_conta'])
            self.ui.labelIntervalo.setText(info_data['intervalo'])
            self.ui.labelVistoUltimo.setText(info_data['dias'])

        def table_membros(self,members_data):
            self.ui.labelTotal.setText(str(len(members_data)))
            self.ui.labelAdicionados.setText(str(sum([1 for member in members_data if member['status'] == '0'])))
            self.ui.labelFalha.setText(str(sum([1 for member in members_data if member['status'] == '1' or member['status'] == '2'])))
            
            for member in members_data:
                rowPosition = self.ui.tableMembros.rowCount()
                self.ui.tableMembros.insertRow(rowPosition)
                self.ui.tableMembros.setItem(rowPosition, 0, QTableWidgetItem(member['user_id']))
                self.ui.tableMembros.setItem(rowPosition, 1, QTableWidgetItem(StatusAddMembro(int(member['status'])).name))
                self.ui.tableMembros.setItem(rowPosition, 2, QTableWidgetItem(member['conta']))
                self.ui.tableMembros.setItem(rowPosition, 3, QTableWidgetItem(member['data']))
                self.ui.tableMembros.setItem(rowPosition, 4, QTableWidgetItem(member['observacao']))
                
                # Center align the text in each cell
                for column in range(self.ui.tableMembros.columnCount()):
                    item = self.ui.tableMembros.item(rowPosition, column)
                    item.setTextAlignment(QtCore.Qt.AlignCenter)

        def table_contas(self, members_data):
            nomes_sem_repetir = list(set([member['conta'] for member in members_data]))

            for i, conta in enumerate(nomes_sem_repetir):
                rowPosition = self.ui.tableContas.rowCount()
                self.ui.tableContas.insertRow(rowPosition)
                item = QTableWidgetItem(nomes_sem_repetir[i])
                item.setTextAlignment(QtCore.Qt.AlignCenter)  
                self.ui.tableContas.setItem(rowPosition, 0, item)
                
                status = self.database.get_account_by_apelido(nomes_sem_repetir[i])
                

                item = QTableWidgetItem(str(StatusConta(status['status_conta']).name if status else 'Desconhecido'))
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                self.ui.tableContas.setItem(rowPosition, 1, item)


                count_status_0 = sum(1 for member in members_data if member['status'] == '0' and member['conta'] == nomes_sem_repetir[i])

                item = QTableWidgetItem(str(count_status_0))
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                self.ui.tableContas.setItem(rowPosition, 2, item)

              
           
           
                