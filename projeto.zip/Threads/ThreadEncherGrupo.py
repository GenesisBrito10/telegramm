import asyncio
import re
from datetime import datetime, timezone
import traceback
from PyQt5.QtCore import QThread, pyqtSignal
from telethon.errors import UserAlreadyParticipantError, ChatAdminRequiredError, FloodWaitError, PeerFloodError
from telethon.tl.functions.channels import JoinChannelRequest, InviteToChannelRequest, GetFullChannelRequest, GetParticipantRequest
from telethon.tl.functions.messages import ImportChatInviteRequest, GetFullChatRequest, AddChatUserRequest
from telethon.tl.types import ChannelParticipantsAdmins, Chat, Channel, ChatParticipantAdmin, ChatParticipantCreator, ChannelForbidden, InputUser, InputPeerSelf, ChannelParticipantSelf, ChannelParticipantAdmin
from telethon import errors
from Model.ClientModel import ClientModel
from Database.Database import Database
from Enums.StatusTarefa import StatusTarefa
from Enums.StatusConta import StatusConta
from Enums.StatusAddMembro import StatusAddMembro
from Threads.ThreadCarregarContas import ThreadCarregarConta

class ThreadEncherGrupo(QThread):
    sinalMsg = pyqtSignal(str)
    sinalAdicionados = pyqtSignal(int)   
    sinalStatus = pyqtSignal(str)
    sinalAnalisados = pyqtSignal(int)
    sinalContaStatus = pyqtSignal(str)
    sinalQuit = pyqtSignal(bool)
    sinalInsertTable = pyqtSignal(bool)
    sinalDeleteTable = pyqtSignal(bool)

    def __init__(self, id_tarefa, accounts, origin_group, target_group, options):
        super().__init__()
        self.client = ClientModel()
        self.db = Database()
        self.id_tarefa = id_tarefa
        self.accounts = accounts
        self.session = accounts[0].get("file_session")
        self.origin_group = origin_group
        self.target_group = target_group
        self.options = options
        self.loop = None

    def extract_hash(self, link):
        patterns = [
            "https://t.me/+", "https://t.me/", "http://t.me/+", "http://t.me/",
            "t.me/+", "https://t.me/joinchat/", "t.me/joinchat/"
        ]
        for pattern in patterns:
            link = link.replace(pattern, "")
        return link

    def run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        
        self.loop.run_until_complete(self.encher_grupo())

       

    async def encher_grupo(self):
        try:
            client = await self.get_client(self.session)
            await client.connect()
            self.sinalStatus.emit('Começando')
            entity_origin = await self.get_entity(client, self.origin_group)
            entity_target = await self.get_entity(client, self.target_group)

            if not entity_origin:
                await self.join_group(client, 'chat', self.extract_hash(self.origin_group))
                entity_origin = await self.get_entity(client, self.origin_group)

            if not entity_target:
                await self.join_group(client, 'chat', self.extract_hash(self.target_group))
                entity_target = await self.get_entity(client, self.target_group)

            full_chat_origin = await self.get_full_chat(client, entity_origin) if entity_origin else None
            full_chat_target = await self.get_full_chat(client, entity_target) if entity_target else None

            if isinstance(entity_target, ChannelForbidden):
                await self.join_group(client, 'channel', self.extract_hash(self.target_group))

            if isinstance(entity_target, Channel):
                is_admin = await self.verify_admin(client, entity_target)
                if not is_admin:
                    await client.disconnect() if client else None
                    self.sinalQuit.emit(False)
                    self.sinalDeleteTable.emit(True)
                    self.loop.close()
                    return
                self.sinalInsertTable.emit(True)



            if full_chat_origin and full_chat_target:
                participants = await self.extract_members(client, entity_origin, full_chat_origin)
                admins = await self.extract_admins(client, entity_origin, full_chat_origin)
                selected_participants = await self.filter_participants(client, participants, admins)
                self.sinalAnalisados.emit(100)
                await self.add_members_to_group(client, selected_participants, entity_target)

        except Exception as e:
            traceback.print_exc()
            await client.disconnect() if client else None
            self.sinalMsg.emit(f"Erro ao adicionar membros: {str(e)}")
            self.sinalQuit.emit(False)
            self.loop.close()

   
    async def verify_admin(self, client, entity):
        me = await client.get_me()
        
        try:
            participant = await client(GetParticipantRequest(entity, me))
            

            if isinstance(participant.participant, ChannelParticipantSelf):
                #print('You are a member of this channel but is not admin.')
                self.sinalMsg.emit('Você é um membro deste grupo, mas não é um administrador.')
                
                return False

            elif isinstance(participant.participant, ChannelParticipantAdmin):

                #print('You are an admin of this channel.') if participant.participant.admin_rights.invite_users else print('You are an admin of this channel, but dont have permissions to add users.')
                None if participant.participant.admin_rights.invite_users else self.sinalMsg.emit('Você é um administrador deste grupo, mas não tem permissão para adicionar usuários.')
                return True if participant.participant.admin_rights.invite_users else False
            else:
                #print('You are not a member of this channel.')
                self.sinalMsg.emit('Você não é um membro deste grupo.')
                return False

                #await self.join_group('channel', self.extract_hash(self.target_group))
        except Exception as e:
            #print('You are not a member of this channel. ',e)
            self.sinalMsg.emit('Você não é um membro deste grupo.')
            return False
            #await self.join_group('channel', self.extract_hash(self.target_group))

    async def add_members_to_group(self, client_atual, participants, group_entity):
       
        self.total_added = 0
        tot_contas = len(self.accounts)
        tot_contas_usadas = 0
        for i, user in enumerate(participants):
            try:
                    
                if user and not isinstance(user, InputPeerSelf):
                    await self.add_user_to_group(client_atual, user, group_entity,tot_contas_usadas)
                    
                    #self.sinalProgresso.emit(int((i + 1) / len(participants) * 100))

                    if self.total_added >= self.options.get("limite_dia", 10):
                        print(f"Limite diário atingido: {self.total_added} membros adicionados.")
                        #self.sinalMsg.emit(f"Limite diário atingido: {self.total_added} membros adicionados.")
                        tot_contas_usadas += 1

                        if tot_contas_usadas >= tot_contas:
                            self.sinalMsg.emit("Todas as contas foram utilizadas.")
                            self.sinalStatus.emit(StatusTarefa.FINALIZADA.name)
                            self.db.update_campo_tarefa(self.id_tarefa, "status", StatusTarefa.PAUSADO_LIMITE_ADD_DIA.value)
                            break
                        
                        if tot_contas_usadas < tot_contas:
                            client_atual = await self.switch_client(client_atual, tot_contas_usadas)
                            if not client_atual:
                                break
                        else:
                            break

            except (FloodWaitError, PeerFloodError) as e:
                self.handle_flood_error(e, tot_contas_usadas, tot_contas)
                print(f"Erro de Flood: {str(e)} na conta {self.accounts[tot_contas_usadas].get('file_session')}")
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                self.load_accounts_thread = ThreadCarregarConta()
                await self.load_accounts_thread.load_accounts()
                if tot_contas_usadas >= tot_contas:
                    client_atual = await self.switch_client(client_atual, tot_contas_usadas)
                    if not client_atual:
                        break
                else:
                    break

            except UserAlreadyParticipantError:
                continue

            except errors.InputUserDeactivatedError:
                continue

            except errors.UserPrivacyRestrictedError as e:
                print (f"can't add {user} due to the user privacy setting")
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                continue
            except errors.UserNotMutualContactError as e:
                print(f'{user} probably was in this group early, but leave it')
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                continue
            except errors.UserChannelsTooMuchError as e:
                print(f'{user} is already in too many channels/supergroups.')
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                continue
            except errors.UserKickedError as e:
                print(f'{user} was kicked from this supergroup/channel')
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
            except errors.UserBannedInChannelError as e:
                print (f'{user}was banned from sending messages in supergroups/channels')
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                continue
            except errors.UserBlockedError as e:
                print(f'{user} User blocked')
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                continue
            except errors.UserIdInvalidError as e:
                print(f'{user} User id is invalid')
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                continue

            except errors.ChatWriteForbiddenError as e:
                self.sinalMsg.emit(f"Você não tem permissão para adicionar membros ao grupo {group_entity.title}.")
                self.db.update_campo_tarefa(self.id_tarefa, "status", StatusTarefa.FALHA.value)
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                break

            except Exception as e:
                traceback.print_exc()
                self.sinalMsg.emit(f"Erro ao adicionar membro: {str(e)}")
                self.db.update_campo_tarefa(self.id_tarefa, "status", StatusTarefa.FALHA.value)
                self.db.insert_membro(self.id_tarefa,user.id,StatusAddMembro.FALHA.value,self.accounts[tot_contas_usadas].get("apelido"),str(e),datetime.now().strftime("%d-%m-%Y"))
                continue

            await asyncio.sleep(self.options.get("intervalo", 0))

        self.db.update_campo_tarefa(self.id_tarefa, "status", StatusTarefa.FINALIZADA.value)
        self.sinalStatus.emit(StatusTarefa.FINALIZADA.name)
        await client_atual.disconnect()
        #self.sinalMsg.emit(f"{self.total_added} membros adicionados ao grupo {group_entity.title}.")

    

    async def add_user_to_group(self, client_atual, member, group_entity,tot_contas_usadas):
        if isinstance(group_entity, Channel):
            mm = InputUser(member.id,member.access_hash)
            await client_atual(InviteToChannelRequest(group_entity.id, [mm]))
        else:
            await client_atual(AddChatUserRequest(group_entity.id, member.id, fwd_limit=10))
        
        self.total_added += 1
        self.sinalAdicionados.emit(self.total_added)
        self.db.insert_membro(self.id_tarefa,member.id,StatusAddMembro.SUCESSO.value,self.accounts[tot_contas_usadas].get("apelido"),StatusAddMembro.SUCESSO.name,datetime.now().strftime("%d-%m-%Y"))

    async def switch_client(self, client_atual, tot_contas_usadas):
        try:
            await client_atual.disconnect()
            self.sinalMsg.emit(f"Trocando para a conta {self.accounts[tot_contas_usadas].get('file_session')}")
            new_client = await self.get_client(self.accounts[tot_contas_usadas].get("file_session"))
            await new_client.connect()
            print(f"Conta {self.accounts[tot_contas_usadas].get('file_session')} conectada.")
            return new_client
        except Exception as e:
            self.sinalMsg.emit(f"Erro ao trocar de conta: {str(e)}")
            self.db.update_account_status(self.accounts[tot_contas_usadas].get("file_session"), StatusConta.NAO_AUTENTICADA.value)
            self.sinalStatus.emit(StatusTarefa.FALHA.name)
            return None

    def handle_flood_error(self, error, tot_contas_usadas, tot_contas):
        if isinstance(error, FloodWaitError):
            self.sinalMsg.emit(f"Erro de Flood: Aguarde {error.seconds} segundos.")
        else:
            self.sinalMsg.emit("Erro de Flood: Ação bloqueada temporariamente.")

        self.db.update_account_status(self.accounts[tot_contas_usadas].get("file_session"), StatusConta.FLOOD)
       
        #self.sinalContaStatus.emit(self.accounts[tot_contas_usadas].get("file_session"),StatusConta.FLOOD.name)
        

        if tot_contas_usadas >= tot_contas:
            self.sinalMsg.emit("Todas as contas estão com Flood.")
            self.db.update_campo_tarefa(self.id_tarefa, "status", StatusTarefa.PAUSADO_FLOOD.value)

    async def get_client(self, session):
        client = self.client.get_client(session)
        await client.connect()

        if not await client.is_user_authorized():
            await client.disconnect()
            self.sinalMsg.emit("Erro: Usuário Banido ou não autorizado. Conecte Novamente.")
            self.db.update_account_status(session, StatusConta.NAO_AUTENTICADA)
            return None

        return client

    async def get_entity(self, client, invite_link):
        try:
            return await client.get_entity(invite_link)
        except Exception:
            return None

    async def get_full_chat(self, client, entity):
        chat_id = entity.id

        if isinstance(entity, Chat):
            full_chat = await client(GetFullChatRequest(chat_id))
            return full_chat.full_chat

        if isinstance(entity, Channel):
            full_chat = await client(GetFullChannelRequest(chat_id))
            return full_chat.full_chat

        return None

    async def extract_members(self, client, group_entity, full_chat):
        try:
            if isinstance(group_entity, Chat):
                return [participant for participant in full_chat.participants.participants]

            if isinstance(group_entity, Channel):
                return [user async for user in client.get_participants(group_entity.id)]

        except errors.FloodWaitError as e:
            self.sinalMsg.emit(f"Erro de Flood extract: {str(e)}")
            print(f"Erro de Flood extract: {str(e)}")
        except errors.ChatAdminRequiredError:
            self.sinalMsg.emit("Erro: Administração do chat requerida.")
            print("Erro: Administração do chat requerida.")
        except Exception as e:
            self.sinalMsg.emit(f"Erro ao extrair membros: {str(e)}")
            print(f"Erro ao extrair membros: {str(e)}")

        return []

    async def extract_admins(self, client, group_entity, full_chat):
        try:
            if isinstance(group_entity, Chat):
                return [participant.user_id for participant in full_chat.participants.participants
                        if isinstance(participant, (ChatParticipantAdmin, ChatParticipantCreator))]

            if isinstance(group_entity, Channel):
                return [user async for user in client.get_participants(group_entity.id, filter=ChannelParticipantsAdmins)]

        except Exception as e:
            self.sinalMsg.emit(f"Erro ao extrair administradores: {str(e)}")
            print(f"Erro ao extrair administradores: {str(e)}")

        return []

    async def filter_participants(self, client, participants, admins):
        selected_participants = []
        
        for user in participants:
            member = await client.get_entity(user)

            if self.is_valid_member(member, admins):
                selected_participants.append(member)
                
                percent = len(selected_participants) / len(participants) * 100
                self.sinalAnalisados.emit(int(percent))

        return selected_participants

    def is_valid_member(self, member, admins):
        if member.bot:
            return False

        if self.options.get("ativos") and (not member.status or self.is_inactive_member(member)):
            return False

        if self.options.get("telefone") and not member.phone:
            return False

        if self.options.get("foto") and not member.photo:
            return False

        if self.options.get("remover_administradores") and member.id in admins:
            return False

        return True

    def is_inactive_member(self, member):
        last_seen = member.status.was_online if hasattr(member.status, 'was_online') else None
        return last_seen and (datetime.now(timezone.utc) - last_seen).days > self.options.get("intervalo_dia", 0)

    async def join_group(self, client, entity, invite):
        try:
            if entity == 'chat':
                await client(ImportChatInviteRequest(invite))
            else:
                await client(JoinChannelRequest(invite))
        except Exception as e:
            self.sinalMsg.emit(f"Erro ao entrar no grupo: {str(e)}")
