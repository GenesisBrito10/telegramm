from enum import Enum

class StatusAddMembro(Enum):
    SUCESSO = 0
    FLOOD = 1
    FALHA = 2