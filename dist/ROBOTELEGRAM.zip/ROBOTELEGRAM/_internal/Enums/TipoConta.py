from enum import Enum

class TipoConta(Enum):
    ADICIONADA = 0
    IMPORTADA = 1